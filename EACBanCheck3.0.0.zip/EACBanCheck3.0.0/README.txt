----- [ HOW TO USE THE BOT ] -----

Fill in the config.json file.

You will need a API key from Rustbanned.com, the API keys are free!
https://rustbanned.com/devapi/

You will also need your steam API key.
You can find that here https://steamcommunity.com/dev/apikey

You will need a Discord bot token, also free.
Here is how you make a discord bot and invite it to your server.
https://www.writebots.com/discord-bot-token/

Battlemetrics section... This section is not required to be enabled. It is meant for people who use battlemetrics and would like to search
up their bans in discord. To enable this section just get a battlemetrics API key from https://www.battlemetrics.com/developers and make sure to grant it access to the bans section.
Plug that into the Battlemetrics API key section and you're good to go.

Bot prefix is the prefix that you want the command to use.
For example if your prefix is $ your search commands would be $eac or $check.
Commands:
check & eac check for eac bans on a profile.
friends & friend checks to see if a user has EAC banned friends,
bans checks for battlemetrics bans linked to a player.

If you want only a specific role to be able to use the command you can fill in the ROLE_ID_REQUIRED_TO_USE_COMMAND section of the config.
All you need to do is enter in the role ID of the role that you want to be used.

Steps to install:
If you want the bot to run 24/7 you will need a VPS or bot hosting node.
Hosting recommendation -> https://pebblehost.com/bot-hosting

Any further questions, feel free to join my support Discord. 

https://discord.gg/RVePam7pd7